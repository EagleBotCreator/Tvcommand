plugins { id("com.android.library"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.tvcommand.core"; compileSdk = 35
    defaultConfig { minSdk = 26; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
}
dependencies { testImplementation("junit:junit:4.13.2") }
