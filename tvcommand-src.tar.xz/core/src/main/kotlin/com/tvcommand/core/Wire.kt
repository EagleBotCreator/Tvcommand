package com.tvcommand.core

import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Each frame has a fresh 96-bit IV, authenticated by AES-256-GCM.
 * This is an application-layer encrypted protocol, NOT HTTP.
 * A frame's IV cannot be reused; the receiver rejects replayed IVs during its process lifetime.
 */
class Wire(private val input: DataInputStream, private val output: DataOutputStream, secret: ByteArray, private val seen: MutableSet<String> = HashSet()) {
    private val key = SecretKeySpec(secret.copyOf(), "AES")
    private val rng = SecureRandom()
    init { require(secret.size == 32) }

    @Synchronized fun send(data: ByteArray) {
        require(data.size <= MAX_PAYLOAD)
        val iv = ByteArray(12).also(rng::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(data)
        output.writeInt(iv.size + encrypted.size)
        output.write(iv)
        output.write(encrypted)
        output.flush()
    }

    fun receive(): ByteArray {
        val len = input.readInt()
        if (len !in 28..(MAX_PAYLOAD + 28)) throw IOException("Invalid frame length")
        val iv = ByteArray(12).also(input::readFully)
        val encrypted = ByteArray(len - 12).also(input::readFully)
        val nonce = iv.joinToString("") { "%02x".format(it.toInt() and 255) }
        synchronized(seen) {
            if (!seen.add(nonce)) throw IOException("Replay detected")
            if (seen.size > 100_000) throw IOException("Nonce budget exhausted; restart receiver")
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted)
    }

    companion object {
        const val MAX_PAYLOAD = 70 * 1024
        fun freshSecret(): ByteArray = ByteArray(32).also(SecureRandom()::nextBytes)
        fun hex(data: ByteArray): String = data.joinToString("") { "%02x".format(it.toInt() and 255) }
        fun fromHex(hex: String): ByteArray {
            require(hex.length == 64 && hex.all { it in "0123456789abcdefABCDEF" })
            return ByteArray(32) { i -> hex.substring(i*2, i*2+2).toInt(16).toByte() }
        }
        fun sha256(stream: InputStream): Pair<String, Long> {
            val hash = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(64 * 1024)
            var count = 0L
            stream.use { s -> while (true) {
                val n = s.read(buffer)
                if (n < 0) break
                if (n > 0) { hash.update(buffer, 0, n); count += n }
            } }
            return hex(hash.digest()) to count
        }
    }
}

object Protocol {
    const val PORT = 39047
    const val OFFER = 1
    const val UPLOAD = 2
    const val LIST = 3
    const val DELETE = 4
    const val PLAY = 5
    const val STOP = 6
    const val PAUSE = 7
    const val OK = 20
    const val ERROR = 21
    const val CHUNK = 30
    const val END = 31
    const val MAX_BYTES = 1024L * 1024 * 1024
    fun packet(type: Int, write: (DataOutputStream) -> Unit = {}): ByteArray =
        ByteArrayOutputStream().also { b -> DataOutputStream(b).use { out -> out.writeInt(type); write(out) } }.toByteArray()
    fun parse(frame: ByteArray): DataInputStream = DataInputStream(ByteArrayInputStream(frame))
    fun safeName(original: String): String {
        val s = original.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(90)
        require(s.isNotBlank() && s != "." && s != "..")
        return s
    }
}
