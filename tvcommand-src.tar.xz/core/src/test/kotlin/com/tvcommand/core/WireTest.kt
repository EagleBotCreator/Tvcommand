package com.tvcommand.core

import org.junit.Assert.*
import org.junit.Test
import java.io.*

class WireTest {
    private val key = Wire.freshSecret()

    @Test fun hexRoundTrip() = assertArrayEquals(key, Wire.fromHex(Wire.hex(key)))

    @Test fun encryptedFrameRoundTrip() {
        val output = ByteArrayOutputStream()
        val sender = Wire(DataInputStream(ByteArrayInputStream(byteArrayOf())), DataOutputStream(output), key)
        sender.send(Protocol.packet(Protocol.OFFER) { it.writeUTF("test.mp4") })
        val receiver = Wire(DataInputStream(ByteArrayInputStream(output.toByteArray())), DataOutputStream(ByteArrayOutputStream()), key)
        val packet = Protocol.parse(receiver.receive())
        assertEquals(Protocol.OFFER, packet.readInt())
        assertEquals("test.mp4", packet.readUTF())
    }

    @Test(expected = Exception::class) fun tamperedCiphertextFails() {
        val output = ByteArrayOutputStream()
        Wire(DataInputStream(ByteArrayInputStream(byteArrayOf())), DataOutputStream(output), key).send("hello".toByteArray())
        val bytes = output.toByteArray(); bytes[bytes.lastIndex] = (bytes.last().toInt() xor 1).toByte()
        Wire(DataInputStream(ByteArrayInputStream(bytes)), DataOutputStream(ByteArrayOutputStream()), key).receive()
    }

    @Test fun deterministicSha256() {
        val (digest, size) = Wire.sha256(ByteArrayInputStream("abc".toByteArray()))
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", digest)
        assertEquals(3L, size)
    }
}
