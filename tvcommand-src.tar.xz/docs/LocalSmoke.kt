import com.tvcommand.core.Protocol
import com.tvcommand.core.Wire
import java.io.*

fun main() {
    val key = Wire.freshSecret()
    check(Wire.fromHex(Wire.hex(key)).contentEquals(key))
    val bytes = ByteArrayOutputStream()
    Wire(DataInputStream(ByteArrayInputStream(byteArrayOf())), DataOutputStream(bytes), key)
        .send(Protocol.packet(Protocol.OFFER) { it.writeUTF("clip.mp4") })
    val frame = bytes.toByteArray()
    val replayCache = mutableSetOf<String>()
    fun receive(input: ByteArray) = Wire(DataInputStream(ByteArrayInputStream(input)), DataOutputStream(ByteArrayOutputStream()), key, replayCache).receive()
    val decoded = Protocol.parse(receive(frame))
    check(decoded.readInt() == Protocol.OFFER && decoded.readUTF() == "clip.mp4")
    check(runCatching { receive(frame) }.isFailure) { "Replay accepted" }
    val corrupt = frame.copyOf(); corrupt[corrupt.lastIndex] = (corrupt.last().toInt() xor 1).toByte()
    check(runCatching { receive(corrupt) }.isFailure) { "Tampered ciphertext accepted" }
    check(Wire.sha256(ByteArrayInputStream("abc".toByteArray())).first == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    check(Protocol.safeName("../../f/file.mp4") == ".._.._f_file.mp4")
    println("PASS: secret round trip, encrypted frame, replay rejection, tamper rejection, SHA-256, file sanitization")
}
