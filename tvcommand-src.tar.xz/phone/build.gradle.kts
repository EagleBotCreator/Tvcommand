plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.tvcommand.phone"; compileSdk = 35
    defaultConfig { applicationId = "com.tvcommand.phone"; minSdk = 26; targetSdk = 28; versionCode = 1; versionName = "0.1" }
}
dependencies { implementation(project(":core")) }
