package com.tvcommand.phone

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.graphics.Color
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import com.tvcommand.core.Protocol
import com.tvcommand.core.Wire
import java.io.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var ip: EditText
    private lateinit var key: EditText
    private lateinit var status: TextView
    private lateinit var library: LinearLayout
    private var chosen: Uri? = null
    private var selectedName: String? = null
    private val pickCode = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 30, 22, 12)
            setBackgroundColor(Color.rgb(13, 20, 35))
        }
        setContentView(page)
        page.addView(text("TV COMMAND", 28))
        page.addView(text("Owner control • Local Wi-Fi", 15))
        ip = EditText(this).apply {
            hint = "TV IP address, e.g. 192.168.1.20"
            setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT
            setText(getPreferences(MODE_PRIVATE).getString("lastIp", ""))
        }
        page.addView(ip)
        key = EditText(this).apply {
            hint = "64-digit pairing key displayed on TV"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        page.addView(key)
        status = text("Open TV Command Receiver on your TV. Show its pairing key and enter it here.", 14)
        page.addView(status)
        page.addView(button("Test connection / Refresh library") { refresh() })
        page.addView(button("Choose a file to send") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, pickCode)
        })
        page.addView(button("Send selected file") { upload() })
        page.addView(button("Pause TV playback") { command(Protocol.PAUSE) })
        page.addView(button("Stop TV playback") { command(Protocol.STOP) })
        page.addView(text("TV library", 20))
        library = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(library) }
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    @Deprecated("Android file picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            chosen = data?.data
            selectedName = chosen?.let(::displayName)
            report("Selected: ${selectedName ?: "None"}")
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "received_file"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return Protocol.safeName(name)
    }

    private fun report(message: String) { runOnUiThread { status.text = message } }

    private fun settings(): Pair<String, ByteArray> {
        val host = ip.text.toString().trim()
        require(host.isNotEmpty() && !host.contains('/')) { "Enter your TV IP address" }
        val secret = Wire.fromHex(key.text.toString().trim())
        getPreferences(MODE_PRIVATE).edit().putString("lastIp", host).apply()
        return host to secret
    }

    private fun <T> connect(connection: Pair<String, ByteArray>, block: (Wire) -> T): T {
        val (host, secret) = connection
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, Protocol.PORT), 5_000)
            socket.soTimeout = 60_000
            val wire = Wire(DataInputStream(BufferedInputStream(socket.getInputStream())),
                DataOutputStream(BufferedOutputStream(socket.getOutputStream())), secret)
            return block(wire)
        }
    }

    private fun response(wire: Wire): String {
        val reply = Protocol.parse(wire.receive())
        val kind = reply.readInt()
        val message = reply.readUTF()
        if (kind != Protocol.OK) throw IOException(message)
        return message
    }

    private fun command(kind: Int, name: String? = null) {
        val connection = try { settings() } catch (e: Exception) { report("Pairing: ${e.message}"); return }
        thread(name = "owner-command") {
            try {
                val message = connect(connection) { wire ->
                    wire.send(Protocol.packet(kind) { out -> if (name != null) out.writeUTF(name) })
                    response(wire)
                }
                report(message)
                if (kind == Protocol.DELETE) refresh()
            } catch (e: Exception) { report("Error: ${e.message}") }
        }
    }

    private fun refresh() {
        val connection = try { settings() } catch (e: Exception) { report("Pairing: ${e.message}"); return }
        thread(name = "library-refresh") {
            try {
                val names = connect(connection) { wire ->
                    wire.send(Protocol.packet(Protocol.LIST))
                    val answer = Protocol.parse(wire.receive())
                    val type = answer.readInt()
                    if (type != Protocol.OK) throw IOException(answer.readUTF())
                    val count = answer.readInt()
                    if (count !in 0..300) throw IOException("Invalid file count")
                    List(count) { answer.readUTF() }
                }
                runOnUiThread {
                    status.text = "Connected. ${names.size} files on TV."
                    library.removeAllViews()
                    names.forEach { name ->
                        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                        row.addView(text(name, 12), LinearLayout.LayoutParams(0, -2, 1f))
                        row.addView(button("Play") { command(Protocol.PLAY, name) })
                        row.addView(button("Delete") {
                            AlertDialog.Builder(this).setTitle("Delete file?")
                                .setMessage(name).setPositiveButton("Delete") { _, _ ->
                                    command(Protocol.DELETE, name)
                                }.setNegativeButton("Cancel", null).show()
                        })
                        library.addView(row)
                    }
                }
            } catch (e: Exception) { report("Connection failed: ${e.message}") }
        }
    }

    private fun upload() {
        val uri = chosen ?: run { report("Choose a file first"); return }
        val name = selectedName ?: return
        // The explicit owner-side Send tap is approval for this single file.
        AlertDialog.Builder(this).setTitle("Approve upload to TV?")
            .setMessage("Send $name to your TV? APK files will be stored, not installed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send") { _, _ -> transfer(uri, name) }.show()
    }

    private fun transfer(uri: Uri, name: String) {
        val connection = try { settings() } catch (e: Exception) { report("Pairing: ${e.message}"); return }
        thread(name = "owner-upload") {
            try {
                report("Checking file integrity...")
                val (hash, size) = contentResolver.openInputStream(uri)?.let(Wire::sha256)
                    ?: throw IOException("Unable to open file")
                if (size !in 1..Protocol.MAX_BYTES) throw IOException("File must be between 1 byte and 1 GiB")
                val approval = connect(connection) { wire ->
                    wire.send(Protocol.packet(Protocol.OFFER) { out ->
                        out.writeUTF(name); out.writeLong(size); out.writeUTF(hash)
                    })
                    response(wire)
                }
                report("Sending $name ...")
                val completed = connect(connection) { wire ->
                    wire.send(Protocol.packet(Protocol.UPLOAD) { it.writeUTF(approval) })
                    response(wire) // READY, only after TV has checked approval
                    contentResolver.openInputStream(uri)?.use { stream ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = stream.read(buffer)
                            if (n < 0) break
                            if (n > 0) wire.send(Protocol.packet(Protocol.CHUNK) { out ->
                                out.writeInt(n); out.write(buffer, 0, n)
                            })
                        }
                    } ?: throw IOException("Source became unavailable")
                    wire.send(Protocol.packet(Protocol.END))
                    response(wire)
                }
                report("Transferred and verified: $completed")
                refresh()
            } catch (e: Exception) { report("Upload failed: ${e.message}") }
        }
    }

    private fun text(message: String, size: Int) = TextView(this).apply {
        text = message; textSize = size.toFloat(); setTextColor(Color.WHITE)
        setPadding(4, 9, 4, 9)
    }
    private fun button(message: String, action: () -> Unit) = Button(this).apply {
        text = message; setOnClickListener { action() }
    }
}
