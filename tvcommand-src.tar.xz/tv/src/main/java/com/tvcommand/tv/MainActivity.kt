package com.tvcommand.tv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.tvcommand.core.Wire
import java.io.File
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var video: VideoView
    private lateinit var status: TextView
    private lateinit var files: LinearLayout
    private lateinit var server: TvServer
    private lateinit var secret: ByteArray

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("receiver", MODE_PRIVATE)
        val saved = prefs.getString("secret", null)
        secret = if (saved != null) Wire.fromHex(saved) else Wire.freshSecret().also {
            prefs.edit().putString("secret", Wire.hex(it)).apply()
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 20, 32, 16)
            setBackgroundColor(Color.rgb(14, 20, 34))
        }
        setContentView(root)
        val title = label("TV COMMAND  |  Receiver", 28); root.addView(title)
        status = label("Waiting for owner phone...", 17); root.addView(status)
        root.addView(label("TV IP: ${ipAddress()}    Port: 39047", 18))
        val keyLabel = label("Pairing key hidden. Use Show Key on TV to pair.", 14)
        root.addView(keyLabel)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(controls)
        controls.addView(button("Show pairing key") { keyLabel.text = Wire.hex(secret) })
        controls.addView(button("Hide pairing key") { keyLabel.text = "Pairing key hidden" })
        controls.addView(button("Reset owner key") {
            secret = Wire.freshSecret()
            prefs.edit().putString("secret", Wire.hex(secret)).apply()
            server.stop()
            keyLabel.text = Wire.hex(secret)
            status.text = "Receiver key reset. Restart TV Command to reconnect."
        })
        video = VideoView(this)
        root.addView(video, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 220))
        video.visibility = android.view.View.GONE
        files = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(files) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("Refresh library") { refreshFiles() })
        server = TvServer(secret, filesDir, { runOnUiThread { refreshFiles() } },
            { file -> runOnUiThread { play(file) } },
            { runOnUiThread { video.stopPlayback(); video.visibility = android.view.View.GONE } },
            { runOnUiThread { if (video.isPlaying) video.pause() } })
        server.start()
        refreshFiles()
    }

    private fun play(file: File) {
        video.visibility = android.view.View.VISIBLE
        video.setVideoPath(file.absolutePath)
        video.setOnErrorListener { _, _, _ -> status.text = "Cannot play ${file.name}"; true }
        video.start()
        status.text = "Playing ${file.name}"
    }

    private fun refreshFiles() {
        files.removeAllViews()
        files.addView(label("Received files", 21))
        val all = File(filesDir, "library").listFiles()?.filter { it.isFile } ?: emptyList()
        if (all.isEmpty()) files.addView(label("No files yet", 16))
        all.forEach { file -> files.addView(button(file.name) { if (!file.name.endsWith(".apk", true)) play(file) }) }
    }

    private fun label(value: String, size: Int) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(Color.WHITE); setPadding(6, 8, 6, 8)
    }
    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value; setOnClickListener { action() }; isFocusable = true
    }
    private fun ipAddress(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }?.hostAddress ?: "Unknown"
    } catch (_: Exception) { "Unknown" }

    override fun onDestroy() { server.stop(); super.onDestroy() }
}
