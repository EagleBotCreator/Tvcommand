package com.tvcommand.tv

import com.tvcommand.core.Protocol
import com.tvcommand.core.Wire
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Collections
import java.util.UUID
import kotlin.concurrent.thread

/** Receiver stays active only while its Activity is open. One client at a time. */
class TvServer(
    private val secret: ByteArray,
    private val root: File,
    private val onLibraryChanged: () -> Unit,
    private val onPlay: (File) -> Unit,
    private val onStop: () -> Unit,
    private val onPause: () -> Unit
) {
    @Volatile private var running = true
    private var server: ServerSocket? = null
    private val usedNonces = Collections.synchronizedSet(HashSet<String>())
    private val pending = mutableMapOf<String, Offer>()
    private val library = File(root, "library")
    private val staging = File(root, "staging")

    private data class Offer(val id: String, val name: String, val size: Long, val hash: String, val expires: Long)

    fun start() {
        library.mkdirs()
        staging.mkdirs()
        staging.listFiles()?.forEach { it.delete() }
        thread(name = "tv-command-listener") {
            try {
                ServerSocket(Protocol.PORT).use { socket ->
                    server = socket
                    while (running) {
                        val client = try { socket.accept() } catch (_: IOException) { break }
                        client.use { connection ->
                            try { handle(connection) } catch (_: Exception) { /* invalid requests are dropped */ }
                        }
                    }
                }
            } catch (_: IOException) { /* port unavailable */ }
        }
    }

    fun stop() { running = false; server?.close() }

    private fun handle(socket: Socket) {
        socket.soTimeout = 60_000
        val wire = Wire(DataInputStream(BufferedInputStream(socket.getInputStream())),
            DataOutputStream(BufferedOutputStream(socket.getOutputStream())), secret, usedNonces)
        val request = Protocol.parse(wire.receive())
        when (request.readInt()) {
            Protocol.OFFER -> {
                val name = Protocol.safeName(request.readUTF())
                val size = request.readLong()
                val hash = request.readUTF()
                if (size !in 1..Protocol.MAX_BYTES || !hash.matches(Regex("[a-fA-F0-9]{64}")) ||
                    pending.size >= 10 || library.usableSpace < size + 256L * 1024 * 1024) {
                    fail(wire, "Invalid upload or insufficient storage"); return
                }
                val id = UUID.randomUUID().toString()
                pending[id] = Offer(id, name, size, hash, System.currentTimeMillis()+60_000)
                // An OFFER is sent only by the paired owner following an explicit phone-side Send action.
                ok(wire, id)
            }
            Protocol.UPLOAD -> {
                val id = request.readUTF()
                val offer = pending.remove(id)
                if (offer == null || offer.expires < System.currentTimeMillis()) {
                    fail(wire, "Approval expired"); return
                }
                val temporary = File(staging, "$id.part")
                var published = false
                try {
                    val digest = MessageDigest.getInstance("SHA-256")
                    var total = 0L
                    FileOutputStream(temporary).use { output ->
                        ok(wire, "READY")
                        while (true) {
                            val frame = Protocol.parse(wire.receive())
                            when (frame.readInt()) {
                                Protocol.CHUNK -> {
                                    val count = frame.readInt()
                                    if (count !in 1..(64 * 1024) || count.toLong() > offer.size - total) {
                                        throw IOException("Invalid chunk")
                                    }
                                    val bytes = ByteArray(count)
                                    frame.readFully(bytes)
                                    output.write(bytes)
                                    digest.update(bytes)
                                    total += count
                                }
                                Protocol.END -> break
                                else -> throw IOException("Unexpected frame")
                            }
                        }
                        output.fd.sync()
                    }
                    if (total != offer.size || !Wire.hex(digest.digest()).equals(offer.hash, true)) {
                        fail(wire, "File failed integrity check"); return
                    }
                    val dest = File(library, "${UUID.randomUUID()}_${offer.name}")
                    if (!temporary.renameTo(dest)) { fail(wire, "File commit failed"); return }
                    published = true
                    onLibraryChanged()
                    ok(wire, dest.name)
                } finally { if (!published) temporary.delete() }
            }
            Protocol.LIST -> {
                val names = library.listFiles()?.filter { it.isFile }?.map { it.name } ?: emptyList()
                wire.send(Protocol.packet(Protocol.OK) { out ->
                    out.writeInt(names.size.coerceAtMost(300))
                    names.take(300).forEach(out::writeUTF)
                })
            }
            Protocol.DELETE -> {
                val name = request.readUTF()
                val file = findFile(name)
                if (file != null && file.delete()) { onLibraryChanged(); ok(wire, "Deleted") }
                else fail(wire, "File not found")
            }
            Protocol.PLAY -> {
                val file = findFile(request.readUTF())
                if (file == null || file.extension.equals("apk", true)) fail(wire, "Not playable")
                else { onPlay(file); ok(wire, "Playing") }
            }
            Protocol.PAUSE -> { onPause(); ok(wire, "Paused") }
            Protocol.STOP -> { onStop(); ok(wire, "Stopped") }
            else -> fail(wire, "Unknown command")
        }
    }

    private fun findFile(name: String): File? =
        library.listFiles()?.firstOrNull { it.isFile && it.name == name }

    private fun ok(wire: Wire, message: String) =
        wire.send(Protocol.packet(Protocol.OK) { it.writeUTF(message) })
    private fun fail(wire: Wire, message: String) =
        wire.send(Protocol.packet(Protocol.ERROR) { it.writeUTF(message) })
}
